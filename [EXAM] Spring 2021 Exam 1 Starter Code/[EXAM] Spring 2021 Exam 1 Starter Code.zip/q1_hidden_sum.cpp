#include <iostream>

using std::cout, std::cin, std::endl;

int main () {
}