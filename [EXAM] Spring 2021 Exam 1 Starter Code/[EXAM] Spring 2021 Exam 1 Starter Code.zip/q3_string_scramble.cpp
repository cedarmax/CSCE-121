#include <iostream>

using std::cout, std::cin, std::endl, std::string;

string scrambleWord(string word);

int main() {
	return 0;
}

string scrambleWord(string word) {
	return word;
}
