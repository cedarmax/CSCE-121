// TODO: Implement this source file
#include "MyString.h"
#include <iostream>
MyString::MyString() {

}
MyString::MyString(const MyString &str) {

}
MyString::MyString(const char* s) {

}
MyString::~MyString() {

}
void MyString::resize (size_t n) {}
size_t MyString::capacity() const noexcept {
	return 0;
}
size_t MyString::size() const noexcept {
	return 0;
}
size_t MyString::length() const noexcept {
	return 0;
}
const char* MyString::data() const noexcept {
	return 0;
}
bool MyString::empty() const noexcept {
	return 0;
}
const char& MyString::front() const {
	return '0';
}
const char& MyString::at (size_t pos) const {
	const char i = '0';
	return i;
}
void MyString::clear() noexcept {}
std::ostream MyString::&operator<<(const MyString& str) {
	std::ostream hello;
	return hello;
}
MyString& MyString::operator= (const MyString& str) {
	return *this;
}
MyString& MyString::operator+= (const MyString& str) {
	return *this;
}
size_t MyString::find (const MyString& str, size_t pos = 0) const noexcept {
	return pos;
}
/*
bool MyString::operator== (const MyString& lhs, const MyString& rhs) noexcept {
	return 0;
}
bool MyString::operator== (const char* lhs, const MyString& rhs) {
	return 0;
}
bool MyString::operator== (const MyString& lhs, const char* rhs) {
	return 0;
}
MyString MyString::operator+ (const MyString& lhs, const MyString& rhs) {
	return 0;
}
MyString MyString::operator+ (MyString&& lhs, MyString&& rhs) {
	return 0;
}
MyString MyString::operator+ (MyString&& lhs, const MyString& rhs) {
	return 0;
}
MyString MyString::operator+ (const MyString& lhs, MyString&& rhs) {
	return 0;
}
*/
